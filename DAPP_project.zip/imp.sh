#! /bin/bash
source ~/.nvm/nvm.sh

echo "setting alias python as python2"
alias python=/usr/bin/python2
echo "setting node version 14.16.0 for use"
nvm use 14.16.0
echo "setting truffle alias"
alias truffle=/home/pc/.nvm/versions/node/v14.16.0/bin/truffle




# ./node_modules/.bin/truffle compile