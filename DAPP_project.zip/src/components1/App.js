import React, { useEffect } from 'react';
import './App.css';
//import Token from '../abis/Token.json';
//import Web3 from 'web3';
import Navbar from './Navbar'
import Content from './Content'
import { useSelector, useDispatch } from "react-redux";
import {
  loadWeb3,
  loadAccount,
  loadToken,
  loadExchange
} from '../store/interactions';
import { contractsLoadedSelector } from '../store/selectors';

function App() {

  const dispatch = useDispatch();
  let contractsLoaded = useSelector(contractsLoadedSelector);
  useEffect(()=>{
    loadBlockchainData(dispatch);
  },[]);
  

  window.ethereum.on('chainChanged', (chainId) => {
    // Handle the new chain.
    // Correctly handling chain changes can be complicated.
    // We recommend reloading the page unless you have good reason not to.
    window.location.reload();
  });


  const loadBlockchainData = async (dispatch) => {
    const web3 = await loadWeb3(dispatch)
    const networkId = await web3.eth.net.getId()
    await window.ethereum.enable(); ///////////// added
    await loadAccount(web3, dispatch)
    const token = await loadToken(web3, networkId, dispatch)
    if(!token) {
      window.alert('Token smart contract not detected on the current network. Please select another network with Metamask.')
      return
    }
    const exchange = await loadExchange(web3, networkId, dispatch)
    if(!exchange) {
      window.alert('Exchange smart contract not detected on the current network. Please select another network with Metamask.')
      return
    }
  }

  return (
    <div>
      <Navbar />
      { contractsLoaded ? <Content /> : <div className="content"></div> }
    </div>
  );
}

export default App;